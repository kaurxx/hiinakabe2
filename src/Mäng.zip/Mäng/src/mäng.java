import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class mäng extends Canvas implements Runnable{
    public mäng(){
        handeler = new handeler();
        new aken(640,480,"kk", this);
        //Canvas.setFocus(handeler);

        handeler.addgameobject(new player(50,50,ID.player));
        handeler.addgameobject(new player(200,200,ID.player2));
        this.addKeyListener(new KeyInput(handeler));
    }
    private handeler handeler;
    private Thread thread;
    private boolean running = false;
    public synchronized void start(){
        thread=new Thread(this);
        thread.start();
        running=true;
    }
    public void run(){
        long LastTime = System.nanoTime();
        double amountOfTicks= 60.0;
        double ns= 1000000000/amountOfTicks;
        double delta =0;
        long timer = System.currentTimeMillis();
        int frames =0;
        while(running){
            long now= System.nanoTime();
            delta +=(now - LastTime)/ns;
            LastTime = now;
            while (delta >=1){
                tick();
                delta--;
            }
            if(running)
                render();
            frames++;

            if(System.currentTimeMillis() - timer > 1000){
                System.out.println(frames);
            }
        }
        stop();
    }
    private void tick(){
        handeler.tick();
    }
    private void render(){
        BufferStrategy bs= this.getBufferStrategy();
        if(bs==null){
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        //String imagePath = "path/to/your/Tomaptid.png";
        //BufferedImage myPicture = ImageIO.read(new File(imagePath));
        //g.drawImage();
        g.setColor(Color.black);
        g.fillRect(0,0,640,480);

        handeler.render(g);

        g.dispose();
        bs.show();
    }
    public void stop(){
       try{
           thread.join();
           running=false;
    }catch (Exception e){
       e.printStackTrace();}
    }
    public static void main(String args[]){
        new mäng();

    }

    }
import java.awt.*;

public abstract class gameobject {
    protected int x,y;
    protected ID id;
    protected int velx, vely;
    public gameobject(int x,int y,ID id){
        this.x=x;
        this.y=y;
        this.id=id;

    }
    public abstract void tick();
    public abstract void render(Graphics g);

    public void setx(int x){
        this.x=x;

    }
    public void sety(int y){
        this.y=y;

    }
    public int Getx(){
        return x;
    }
    public int Gety(){
        return y;
    }
    public void SetID(ID id){
        this.id=id;
    }
    public ID GetID(){
        return id;
    }
    public void Setvely(int vely){
        this.vely=vely;
    }
    public void Setvelx(int velx){
        this.velx=velx;
    }
    public int Getvely(){
        return vely;}
    public int Getvelx(){
        return velx;}
}

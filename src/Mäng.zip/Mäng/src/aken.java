import javax.swing.*;
import java.awt.*;
import java.io.Serial;

public class aken extends Canvas {
    public aken(int width, int height, String nimi, mäng game){
        JFrame aken1 = new JFrame(nimi);
        aken1.setPreferredSize(new Dimension(width, height));
        aken1.setMaximumSize(new Dimension(width, height));
        aken1.setMinimumSize(new Dimension(width, height));

        aken1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        aken1.setVisible(true);
        aken1.setResizable(false);
        aken1.setLocationRelativeTo(null);
        aken1.add(game);
        game.start();


    }
}
